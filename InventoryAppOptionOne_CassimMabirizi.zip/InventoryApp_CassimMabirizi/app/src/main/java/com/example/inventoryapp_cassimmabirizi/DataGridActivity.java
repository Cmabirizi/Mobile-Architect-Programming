package com.example.inventoryapp_cassimmabirizi;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;

public class DataGridActivity extends AppCompatActivity {

    EditText itemNameInput, itemQuantityInput;
    Button addItemButton;
    LinearLayout inventoryListLayout;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        itemNameInput = findViewById(R.id.itemNameInput);
        itemQuantityInput = findViewById(R.id.itemQuantityInput);
        addItemButton = findViewById(R.id.addItemButton);
        inventoryListLayout = findViewById(R.id.inventoryListLayout);

        db = new DatabaseHelper(this);

        loadInventory();

        addItemButton.setOnClickListener(v -> {
            String itemName = itemNameInput.getText().toString();
            String itemQuantityStr = itemQuantityInput.getText().toString();

            if (itemName.isEmpty() || itemQuantityStr.isEmpty()) {
                Toast.makeText(this, "Fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(itemQuantityStr);

            // Insert into database
            if (addItem(itemName, quantity)) {
                Toast.makeText(this, "Item Added", Toast.LENGTH_SHORT).show();
                itemNameInput.setText("");
                itemQuantityInput.setText("");
                loadInventory();
            } else {
                Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean addItem(String name, int quantity) {
        return db.getWritableDatabase().insert(
                DatabaseHelper.TABLE_INVENTORY, null,
                dbValues(name, quantity)
        ) != -1;
    }

    private android.content.ContentValues dbValues(String name, int quantity) {
        android.content.ContentValues values = new android.content.ContentValues();
        values.put(DatabaseHelper.COLUMN_ITEM_NAME, name);
        values.put(DatabaseHelper.COLUMN_QUANTITY, quantity);
        return values;
    }

    private void loadInventory() {
        inventoryListLayout.removeAllViews();
        Cursor cursor = db.getReadableDatabase().query(
                DatabaseHelper.TABLE_INVENTORY,
                null, null, null, null, null, null
        );

        if (cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_QUANTITY));
                addItemToView(name, quantity);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    private void addItemToView(String name, int quantity) {
        TextView itemView = new TextView(this);
        itemView.setText(name + " - Qty: " + quantity);
        itemView.setTextSize(16);
        inventoryListLayout.addView(itemView);
    }
}
